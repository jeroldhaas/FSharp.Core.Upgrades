
module X
let v = global.Lib.File1.discState.Second

let v2 = global.Lib.File2.discState.Rep
