
public struct S {
    public int x;
}
