// #Conformance #FSI 
namespace Namespace
type Type = 
    static member Method() = 99
