namespace Project

type B = { Prop : DU }
