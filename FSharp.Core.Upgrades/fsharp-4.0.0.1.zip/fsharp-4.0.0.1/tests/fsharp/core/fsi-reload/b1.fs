namespace Project

type DU = A | B
