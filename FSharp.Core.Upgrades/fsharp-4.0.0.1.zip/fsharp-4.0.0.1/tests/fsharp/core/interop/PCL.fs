﻿namespace PCL

open System

module Lib =

    let year (dt: DateTime) =
        dt.Year
