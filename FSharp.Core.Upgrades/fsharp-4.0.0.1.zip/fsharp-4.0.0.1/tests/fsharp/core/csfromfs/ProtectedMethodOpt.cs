﻿namespace TestBaseClass
{
    public class BaseClass
    {
        protected static int ProtectedStatic() { return 3; }
    }
}

