﻿namespace Library1

type Class1() = 
    member this.X = "C#"
